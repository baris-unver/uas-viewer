SkyG Speed 90B print projects, revision C6B-24 (2026-10-17) - for the Bambu Lab H2S AND H2D

One Bambu Studio project per printed part, oriented as the user manual shows, with every setting embedded (walls,
infill, material per part) and tree supports set to AUTO. There is no G-code inside on purpose: G-code only fits the
printer model it was sliced for. Open the .3mf in Bambu Studio, select your printer (H2S or H2D, 0.4 mm nozzle; the
process settings stay), slice and print. Every part fits both build volumes (340 x 320 x 325 mm). The parts are
checked to print without support, so Bambu adds none or almost none.
Materials (see the BOM): PLA-CF wing halves (2 walls), PETG-CF ailerons, tray, coupler, nut bars, lips, duct inserts,
motor plate, spinner, tail panels and servo horns; PETG camera noses, hatch cover and GPS carrier; ASA tail module and fin. CF filaments need a hardened-steel nozzle.
Every file name ends in _C6B-24: print from one revision only.

Revision C6B-24 (2026-10-17):
- Nut plates NP1 + NP2 joined into one nut frame (NP-nut-frame) that rides on the equipment tray: it sits on four printed pegs on tray pillars in oversized holes (floats +-0.3 mm in x/y, rises to the bore in z), so the wing screws pull the saddles onto the bore and the tray only locates; no epoxy, it comes out with the tray
- Side ledge strips HS-L / HS-R ride on the hatch lips (open-top sockets in HL1 and HL2, rest posts on the GPS cradle walls), no longer epoxied in the tube; HL2's groove for passing under them is gone
- Tube, wing-screw holes, horn slot and drill guide unchanged
