SkyG Speed 90B print projects, revision C6B-16 (2026-10-13) - for the Bambu Lab H2S AND H2D

One Bambu Studio project per printed part, oriented as the user manual shows, with every setting embedded (walls,
infill, material per part) and tree supports set to AUTO. There is no G-code inside on purpose: G-code only fits the
printer model it was sliced for. Open the .3mf in Bambu Studio, select your printer (H2S or H2D, 0.4 mm nozzle; the
process settings stay), slice and print. Every part fits both build volumes (340 x 320 x 325 mm). The parts are
checked to print without support, so Bambu adds none or almost none.
Materials (see the BOM): PLA-CF wing halves (2 walls), PETG-CF ailerons, tray, coupler, nut bars, lips, duct inserts,
motor plate, spinner, tail panels and servo horns; PETG camera noses, hatch cover and GPS carrier; ASA tail module and fin. CF filaments need a hardened-steel nozzle.
Every file name ends in _C6B-16: print from one revision only.

Revision C6B-16 (2026-10-13):
- Aileron hinge line moved from 75 % to 66 % chord (aileron 34 % of the chord, was 25 %): the wing is 4.2-5.3 mm thick there (was 2.8-3.2), so the owner's C6B-15 print had weak, ill-fitting 3.2 mm knuckles and 0.35-0.7 mm of aileron skin round the pin. Two 12 mm wing knuckles as thick as the wing (1.4-1.6 mm wall), 1.5 mm pin kept (a 2.0 mm pin would leave walls under the 1.4 mm rule), aileron nose 1.15-1.65 mm round it
- Free rotation: pin bore clearance 0.125 mm (drill to 1.75 mm by hand), 0.4 mm end gaps at the knuckles, 0.35 mm cove clearance; four 1.2 mm teardrop glue ports on each aileron's underside (three for the pin, one for the torque rod's D-bore) so nothing is glued until the aileron swings freely dry
- Rear wing screws and nut bar 6 mm forward (LE + 52, was 58): the torque-rod horns moved forward with the hinge line
- Finer print settings: wing halves 0.16 mm layers, ailerons 0.12 mm, outer walls 60 mm/s, bores +0.05 mm (X-Y hole compensation); the hinge bores now gate the build (bore_skin)
- Equipment tray stiffened (owner: it bent under the battery): floors 4.4 / 3.2 mm (were 2.8 / 1.6) on a 40 deg sloped base, 1.6 mm flanges behind the pack, under the ESC, beside the FC and at the aft end: sag with the pack 2.9 -> 0.48 mm at 1 g, 0.35 mm at 10 g between the screws (it touched the tube before); +6.7 g
- Tray screw bosses (owner: 'too thin'): each M2 now threads 4.75 mm into a boss built round its axis (was 2.45 mm in a 1.5 mm pad), 44 deg seat under the washer, teardrop pilot roof, no support
- USB-C socket (owner: no cable entrance): the holder has an open-topped slot in its aft wall for the extension lead to the FC; the socket moved 5 mm forward and 1.6 mm inboard so the plug drops in from above clear of the hatch edge
- DJI nose N0O print artifacts: seam moved to the top centreline (it ran through the left NACA and in a column by the spigot screw hole), walls 60 / 100 mm/s, Arachne walls, one fan speed, 8 s slow-down; NACA pockets start 0.6 mm deep, duct gable over the duct only, camera-clamp counterbores meet the skin square (0.36 mm films gone)
- Manual: the hinge step described glue holes the aileron did not have, and the torque-rod step an old horn-and-pin bend; both rewritten
