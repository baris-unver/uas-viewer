SkyG Speed 90B print projects, revision C6B-15 (2026-10-12) - for the Bambu Lab H2S AND H2D

One Bambu Studio project per printed part, oriented as the user manual shows, with every setting embedded (walls,
infill, material per part) and tree supports set to AUTO. There is no G-code inside on purpose: G-code only fits the
printer model it was sliced for. Open the .3mf in Bambu Studio, select your printer (H2S or H2D, 0.4 mm nozzle; the
process settings stay), slice and print. Every part fits both build volumes (340 x 320 x 325 mm). The parts are
checked to print without support, so Bambu adds none or almost none.
Materials (see the BOM): PLA-CF wing halves (2 walls), PETG-CF ailerons, tray, coupler, nut bars, lips, duct inserts,
motor plate, spinner, tail panels and servo horns; PETG camera noses, hatch cover and GPS carrier; ASA tail module and fin. CF filaments need a hardened-steel nozzle.
Every file name ends in _C6B-15: print from one revision only.

Revision C6B-15 (2026-10-12):
- Wing spar 180 mm (90 mm into each half, was 400 / 200): the owner's printed wing had a raised ridge along the outer top face where the 5 mm bore left 0.35-1.3 mm of skin; the bore now keeps >= 1.4 mm (flutter 137 -> about 120 m/s, required 108)
- Ailerons print together on one plate (AP-ailerons-pair) with 80 % fan and a 3 mm/s slow-down floor: the slanted tip's last 15 mm had printed in 0.2-5 s layers and melted on the owner's print
- New gates: design_review bore_skin (skin over round bores, two-wall parts >= 1.4 mm) and a layer-time rule in the G-code audit (runs of layers under 3 s at most 1 mm high); battery stop and window filler slowed for it
- Reported for the owner's decision (unchanged): thin skin over the aileron spine and torque-rod bores, the wing-tip pin bore, the tail shafts and the fin's antenna channel
