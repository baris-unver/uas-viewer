SkyG Speed 90B print projects, revision C6B-20 (2026-10-16) - for the Bambu Lab H2S AND H2D

One Bambu Studio project per printed part, oriented as the user manual shows, with every setting embedded (walls,
infill, material per part) and tree supports set to AUTO. There is no G-code inside on purpose: G-code only fits the
printer model it was sliced for. Open the .3mf in Bambu Studio, select your printer (H2S or H2D, 0.4 mm nozzle; the
process settings stay), slice and print. Every part fits both build volumes (340 x 320 x 325 mm). The parts are
checked to print without support, so Bambu adds none or almost none.
Materials (see the BOM): PLA-CF wing halves (2 walls), PETG-CF ailerons, tray, coupler, nut bars, lips, duct inserts,
motor plate, spinner, tail panels and servo horns; PETG camera noses, hatch cover and GPS carrier; ASA tail module and fin. CF filaments need a hardened-steel nozzle.
Every file name ends in _C6B-20: print from one revision only.

Revision C6B-20 (2026-10-16):
- Hatch lips screwed to the equipment tray, no epoxy (owner: "Screwed lips (B)"): each lip's legs hug the bore down to foot tabs on two new tray pillars, one M2 x 6 socket-head screw per tab; printed 0.2 mm fork shims (LS, 0-3 per tab, fitted once) set the hatch cover flush; the cover screws go into brass M2 heat-set inserts in the lip bosses; the lips slide in and out with the tray
- Fin held in a dorsal shoe on the tail module, no glue (owner: "dorsal shoe clamp (b)"): 2.2 mm shoe walls 9.5 mm above the crown, two flush M2 x 12 countersunk screws from the left in printed washers into brass M2 heat-set inserts in the right wall; F3 14.2 -> 16.5 g; the ELRS dipole threads up into the fin's closed channel from the root (taped at the root face, no glue); nearest metal 10.3 mm from the dipole; F3 seam pinned at -42 deg
- Wing-window filler WF with two outside fillets (owner: "filler with outside fillets"): they rest on the carbon along both window edges under the wing root (0.05 mm fit), so negative g, roll and knocks bear on the tube instead of the nut-bar bonds; WF not glued, held between the root and the tube by the four wing screws, sanded or taped to zero play; nut bars on a thin locator bead only. WF 8.6 g, 32 min. Tube openings, screws and the cutting template unchanged (tube already cut)
- One heat-set insert type (M2, 3 mm long, 3.0 mm hole) for hatch lips and fin, 4 per aircraft; 18 printed washers. All-up 529.8 g, static margin 7.0 %, battery at x 127.6 (slide 120-130)
- Manual, viewer and BOM updated for the screwed lips, fin shoe and unglued filler (no lip epoxy, no fin CA, no filler epoxy)
