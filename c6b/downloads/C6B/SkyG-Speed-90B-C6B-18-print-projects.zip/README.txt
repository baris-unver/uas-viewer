SkyG Speed 90B print projects, revision C6B-18 (2026-10-15) - for the Bambu Lab H2S AND H2D

One Bambu Studio project per printed part, oriented as the user manual shows, with every setting embedded (walls,
infill, material per part) and tree supports set to AUTO. There is no G-code inside on purpose: G-code only fits the
printer model it was sliced for. Open the .3mf in Bambu Studio, select your printer (H2S or H2D, 0.4 mm nozzle; the
process settings stay), slice and print. Every part fits both build volumes (340 x 320 x 325 mm). The parts are
checked to print without support, so Bambu adds none or almost none.
Materials (see the BOM): PLA-CF wing halves (2 walls), PETG-CF ailerons, tray, coupler, nut bars, lips, duct inserts,
motor plate, spinner, tail panels and servo horns; PETG camera noses, hatch cover and GPS carrier; ASA tail module and fin. CF filaments need a hardened-steel nozzle.
Every file name ends in _C6B-18: print from one revision only.

Revision C6B-18 (2026-10-15):
- Deliberate layer-start seams (owner photos of printed parts): every visible part prints with its seam on a harmless line — airfoils on the trailing edge (wing: hinge-cove lips inside the aileron bay), the nose and tail coupler on a meridian clear of holes and inlets with a scarf seam over the tube-fit bands. The default seam had stacked raised lines round the coupler's screw holes, up the nose spigot (blocked assembly), along the fin's leading edge and on the wing skin
- Seam gate in the G-code audit: a part fails if its seams stack on a hole/cutout edge, a tube-fit band or off its intended line
- Slicing keeps each part's planned turn on the plate (Bambu's auto-arrange had been rotating parts); scarf seams now really print (filament override)
- VTX shelf N0M 3.0 mm, printed solid (was 1.5 mm and flexed): 8x stiffer
- Stabilators print with the Arachne wall generator: fills the blunt trailing edge (fewer voids, no line along the TE)
