SkyG Speed 90B print projects, revision C6B-12 (2026-10-11) - for the Bambu Lab H2S AND H2D

One Bambu Studio project per printed part, oriented as the user manual shows, with every setting embedded (walls,
infill, material per part) and tree supports set to AUTO. There is no G-code inside on purpose: G-code only fits the
printer model it was sliced for. Open the .3mf in Bambu Studio, select your printer (H2S or H2D, 0.4 mm nozzle; the
process settings stay), slice and print. Every part fits both build volumes (340 x 320 x 325 mm). The parts are
checked to print without support, so Bambu adds none or almost none.
Materials (see the BOM): PLA-CF wing halves (2 walls), PETG-CF ailerons, tray, coupler, nut bars, lips, duct inserts,
motor plate, spinner, tail panels and servo horns; PETG camera noses, hatch cover and GPS carrier; ASA tail module and fin. CF filaments need a hardened-steel nozzle.
Every file name ends in _C6B-12: print from one revision only.

Revision C6B-12 (2026-10-11):
- Raspberry Pi nose rain-safe (owner: "update raspi nose like you did it for dji", camera only): its 24 mm face opening is closed by a bought clear acrylic disc (25 x 1 mm) flush in the face; the belly NACA is replaced by the same NACA on each side at mid-height, with a 4 mm floor sill and a 2 mm drain
- DJI O4 nose: the same clear window (20 x 0.5 mm disc): its 18 mm face opening was wider than the 14 mm camera body and let air and rain pass beside the camera into the nose (C6B-8 said there was no forward-facing opening; the checks looked only at the skin)
