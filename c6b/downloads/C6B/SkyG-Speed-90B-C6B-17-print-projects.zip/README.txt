SkyG Speed 90B print projects, revision C6B-17 (2026-10-13) - for the Bambu Lab H2S AND H2D

One Bambu Studio project per printed part, oriented as the user manual shows, with every setting embedded (walls,
infill, material per part) and tree supports set to AUTO. There is no G-code inside on purpose: G-code only fits the
printer model it was sliced for. Open the .3mf in Bambu Studio, select your printer (H2S or H2D, 0.4 mm nozzle; the
process settings stay), slice and print. Every part fits both build volumes (340 x 320 x 325 mm). The parts are
checked to print without support, so Bambu adds none or almost none.
Materials (see the BOM): PLA-CF wing halves (2 walls), PETG-CF ailerons, tray, coupler, nut bars, lips, duct inserts,
motor plate, spinner, tail panels and servo horns; PETG camera noses, hatch cover and GPS carrier; ASA tail module and fin. CF filaments need a hardened-steel nozzle.
Every file name ends in _C6B-17: print from one revision only.

Revision C6B-17 (2026-10-13):
- Stabilator panels thickened over the epoxied 2.5 mm shaft (owner: 4A): NACA0012 at 15 % at the root and 17 % at the shaft's end, back to 12 % at the tip: the skin round the shaft (the panel's whole load path) was 0.61-0.85 mm, now >= 1.4 mm
- Fin NACA0008 -> NACA0011 (owner: 5A): the receiver dipole's channel had 0.79 mm of skin, now >= 1.4 mm; bore_skin now gates the stabilators and fin
- DJI nose window (owner: could not find the window's place): 1.0 mm disc (was 0.5) in a 20.6 mm recess with a 0.64 mm straight step and a 40 deg seat (was 0.2 mm, hidden by first-layer squish on the face-down print); pry notch at the bottom; first-layer compensation 0.25 mm on the nose; manual step rewritten
- Tail joint check corrected (owner asked about the stabilator/tail joint screws): fasteners_C4 probed the joint and coupler screws on the side line, 20-40 deg from where they are, and reported 1.1-1.5 mm of thread; measured at the real screw angles on exact meshes all six (four joint, two coupler) engage 4.9-5.0 mm of thread in their existing bosses; the check now lists all four joint screws and gates >= 4 mm
