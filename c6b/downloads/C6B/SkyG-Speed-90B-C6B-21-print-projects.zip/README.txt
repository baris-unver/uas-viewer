SkyG Speed 90B print projects, revision C6B-21 (2026-10-16) - for the Bambu Lab H2S AND H2D

One Bambu Studio project per printed part, oriented as the user manual shows, with every setting embedded (walls,
infill, material per part) and tree supports set to AUTO. There is no G-code inside on purpose: G-code only fits the
printer model it was sliced for. Open the .3mf in Bambu Studio, select your printer (H2S or H2D, 0.4 mm nozzle; the
process settings stay), slice and print. Every part fits both build volumes (340 x 320 x 325 mm). The parts are
checked to print without support, so Bambu adds none or almost none.
Materials (see the BOM): PLA-CF wing halves (2 walls), PETG-CF ailerons, tray, coupler, nut bars, lips, duct inserts,
motor plate, spinner, tail panels and servo horns; PETG camera noses, hatch cover and GPS carrier; ASA tail module and fin. CF filaments need a hardened-steel nozzle.
Every file name ends in _C6B-21: print from one revision only.

Revision C6B-21 (2026-10-16):
- Hatch lips HL1/HL2 rebuilt stiff (owner: "Lips are too thin"; C6B-20's 1.2 mm hoops let 10 N on the cover screw lift the front boss 17 mm on the bench): 2 mm band and full-width legs, two rails and a floor boxing each screw tab, deepened tongue under the boss, 40 deg self-supporting undersides; now 0.16 / 0.07 mm under 10 N with safety factor 3.1 / 3.7, 20 N side and 30 N insert press checked (new lip_fe.py load cases and design-review gate lip_loads). HL1 4.1 g, HL2 3.5 g (were 1.7 / 1.3)
- Tray pillars r 4.4 and lip shims LS r 4.2 (were 3.4 / 3.2); lip screws enter through a 4.2 mm crown hole; press the brass inserts with the lip on a block before it goes on the tray. Screw positions, tube, tray screws and hatch cover unchanged
- All-up 534.8 g, static margin 7.9 % with the pack at its rear stop (band 6-8 %)
