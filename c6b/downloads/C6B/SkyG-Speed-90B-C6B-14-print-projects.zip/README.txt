SkyG Speed 90B print projects, revision C6B-14 (2026-10-11) - for the Bambu Lab H2S AND H2D

One Bambu Studio project per printed part, oriented as the user manual shows, with every setting embedded (walls,
infill, material per part) and tree supports set to AUTO. There is no G-code inside on purpose: G-code only fits the
printer model it was sliced for. Open the .3mf in Bambu Studio, select your printer (H2S or H2D, 0.4 mm nozzle; the
process settings stay), slice and print. Every part fits both build volumes (340 x 320 x 325 mm). The parts are
checked to print without support, so Bambu adds none or almost none.
Materials (see the BOM): PLA-CF wing halves (2 walls), PETG-CF ailerons, tray, coupler, nut bars, lips, duct inserts,
motor plate, spinner, tail panels and servo horns; PETG camera noses, hatch cover and GPS carrier; ASA tail module and fin. CF filaments need a hardened-steel nozzle.
Every file name ends in _C6B-14: print from one revision only.

Revision C6B-14 (2026-10-11):
- Third pair of tray screws at x 200 (owner), 45 deg below the side line like the others, flush in printed countersunk washers: the 268 mm tray was held down only at its ends
- Printed battery front stop BF (owner): a block ahead of the pack whose two pegs sit in floor holes at the balance ticks (pack rear edge 150 / 155 / 160); the pack slides forward against it, so it cannot move forward in a nose-first landing
- Viewer opens with the DJI O4 nose (owner); parts list: tail-joint screw positions corrected (+20 / -25 deg)
- Battery slide range 108-130 (was 108-128): the stop and the new screws moved the balance position to x 129.2
