SkyG Speed 90B print projects, revision C6B-10 (2026-10-11) - for the Bambu Lab H2S AND H2D

One Bambu Studio project per printed part, oriented as the user manual shows, with every setting embedded (walls,
infill, material per part) and tree supports set to AUTO. There is no G-code inside on purpose: G-code only fits the
printer model it was sliced for. Open the .3mf in Bambu Studio, select your printer (H2S or H2D, 0.4 mm nozzle; the
process settings stay), slice and print. Every part fits both build volumes (340 x 320 x 325 mm). The parts are
checked to print without support, so Bambu adds none or almost none.
Materials (see the BOM): PLA-CF wing halves (2 walls), PETG-CF ailerons, tray, coupler, nut bars, lips, duct inserts,
motor plate, spinner, tail panels and servo horns; PETG camera noses, hatch cover and GPS carrier; ASA tail module and fin. CF filaments need a hardened-steel nozzle.
Every file name ends in _C6B-10: print from one revision only.

Revision C6B-10 (2026-10-11):
- Tail joint screws spread (owner: "why the joint screws on the right side are too close to each other?"): the side-line pair moved 20° up, the second pair stays 25° below; hole centres 15 mm apart (were 8.5 mm, 3.5 mm of skin between the holes)
- Wing-window filler WF stiffened (owner: "looks thin and fragile"): a 2.4 × 2.5 mm rib under each side strip inside the tube, within the window outline so the filler still drops in with the wing, clear of the nut bars
- Screw-hole check: hole centres in one part at least 2.5 × the hole diameter (it measured only to the part's edges)
- Viewer: Escape leaves Isolate first
