SkyG Speed 90B print projects, revision C6B-23 (2026-10-17) - for the Bambu Lab H2S AND H2D

One Bambu Studio project per printed part, oriented as the user manual shows, with every setting embedded (walls,
infill, material per part) and tree supports set to AUTO. There is no G-code inside on purpose: G-code only fits the
printer model it was sliced for. Open the .3mf in Bambu Studio, select your printer (H2S or H2D, 0.4 mm nozzle; the
process settings stay), slice and print. Every part fits both build volumes (340 x 320 x 325 mm). The parts are
checked to print without support, so Bambu adds none or almost none.
Materials (see the BOM): PLA-CF wing halves (2 walls), PETG-CF ailerons, tray, coupler, nut bars, lips, duct inserts,
motor plate, spinner, tail panels and servo horns; PETG camera noses, hatch cover and GPS carrier; ASA tail module and fin. CF filaments need a hardened-steel nozzle.
Every file name ends in _C6B-23: print from one revision only.

Revision C6B-23 (2026-10-17):
- NEW TUBE, CLOSED AT THE WING (owner 2026-10-16/17): no wing-bay window; the tube gets four 3.4 mm vertical wing-screw holes (x 261 / 297, y +-9) and one 12 x 18 mm horn slot (x 304.4-316.4, r 3 corners, drill-first corners); the front hatch window narrows from 28 to 25.6 mm (cover 25 mm). A printed tube DRILL GUIDE (DG, PETG tool) keyed into the hatch window drills the holes and slot corners square
- WING ON TOP: raised 4.3 mm onto the closed crown (0.88 mm clearance), with an integral ROOT FILLET on each half (line-to-line on the tube to +-40 deg: the print-overhang limit; 4 mm round at the contact edge, ends lifting smoothly off the tube); spar, ailerons, torque rods and hinge pins move with it; four countersunk M3 x 20 steel screws in the steel cup washers (was M3 x 16 / x 12 at y +-6.5)
- NUT PLATES NP1 / NP2 (PETG-CF, 3.2 / 2.8 g) replace the window filler WF and the nut bars NB1 / NB2: 5 mm saddles (2.9 mm over the crown where the tray's pin guide passes, 2.4 mm by the MR30), bearing on the bore to +-60 deg, hex pockets; slid in along the crown from the tube's front end, epoxy bead as locator only. Wing-joint FE (scripts/c6b/wing_joint_fe.py, gate wing_joint): +10 g / -5 g / knock / preload SF >= 3.3 printed, >= 11 carbon; 30 N tip strike printed SF 1.24 (p99.5 2.22), carbon 4.3, roll 0.29 deg (0.35 deg on the C6B-22 window joint), accepted by the owner as an abuse case
- AILERON DRIVE: printed FORK HORNS AHR / AHL drop over the pushrods' L-bend pins when the wing goes on (slot pin + 0.05 mm, about 0.1 mm free play at the trailing edge, no keeper); horn 16.3 mm (linkage 3.79:1, +-15 deg at the servo's +-80 deg); a PIN GUIDE on the tray holds both pins with the wing off
- FIN SHOE SYMMETRIC (owner: 'non symmetric'): both bosses with their faces at y +-7.1, M2 x 14 DIN 965 A2 (2.8 mm in the insert), was M2 x 12
- GPS CRADLE IN THE TRAY (owner: HG too thin): side walls, ledges and rear-stop posts on the tray; the bonded HG carrier is gone; the GPS sits 1.8 mm lower (top z 12.2) and goes in from above with the cover off; the USB-C socket moved 2.75 mm inboard (lift the GPS out to plug in)
- HATCH: two glued PETG SIDE LEDGE STRIPS HS-L / HS-R under the window's long edges carry the cover's edges (no gasket); the C6B-21 screwed lips stay, HL2 with a channel along each strip and a pad under it (lip FE: case b peak SF 1.28, accepted by the owner as a bench handling case)
- Removed: window filler WF, nut bars NB1 / NB2, GPS carrier HG
