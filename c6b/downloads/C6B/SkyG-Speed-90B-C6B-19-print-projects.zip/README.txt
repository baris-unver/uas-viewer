SkyG Speed 90B print projects, revision C6B-19 (2026-10-15) - for the Bambu Lab H2S AND H2D

One Bambu Studio project per printed part, oriented as the user manual shows, with every setting embedded (walls,
infill, material per part) and tree supports set to AUTO. There is no G-code inside on purpose: G-code only fits the
printer model it was sliced for. Open the .3mf in Bambu Studio, select your printer (H2S or H2D, 0.4 mm nozzle; the
process settings stay), slice and print. Every part fits both build volumes (340 x 320 x 325 mm). The parts are
checked to print without support, so Bambu adds none or almost none.
Materials (see the BOM): PLA-CF wing halves (2 walls), PETG-CF ailerons, tray, coupler, nut bars, lips, duct inserts,
motor plate, spinner, tail panels and servo horns; PETG camera noses, hatch cover and GPS carrier; ASA tail module and fin. CF filaments need a hardened-steel nozzle.
Every file name ends in _C6B-19: print from one revision only.

Revision C6B-19 (2026-10-15):
- Wing-window filler WF printed the way it sits, outer skin up on solid feet (owner's print: "too thin to print" -- standing 100 mm tall it came out as two lumpy, stringy strips): 9.5 mm tall, 0.12 mm layers, every layer one 100 x 26 mm frame; solid 4.5 mm band under the skin, webs under both ends, short corbelled spans over the wing nut bars, which take matching chamfers. 5.0 g (was 2.6), 23 min (was 59); outer face and window fit unchanged
- New G-code gates (the old filler passed every check): slender free-standing columns of small islands, slow crawl over small islands (heat soak), thin layers closed over air from small islands, and wall-loop bridge spans; any failing part now fails the G-code audit
- GPS carrier HG prints the way it sits (its side walls had been slender standing columns); the rear stop's crown above the cover notch is cut at z 17.3 (two 1.2 mm horns). Micro-camera nose N0M: the pivot slot's top is a pointed arch with a 1.5 mm longer boss (was a 5.4 mm round top over air)
- Ailerons: the new gates flag the thin tip; waived with the owner's C6B-16/17 print ("wings aileron and hinges ... are ok"), geometry and plate settings unchanged
- Manual audit (owner: old parts in the manual): every assembly picture, label and sentence now from the current CAD and parameters (tray and front stop in the battery step, VTX shelf, DJI window and duct insert, 180 mm spar, 2.5 mm shafts in 3 mm bushings, glue ports, printed horns); orientation cards for every printed part; electrical integration chapter and full-size wiring diagram inside the user manual (one file); viewer descriptions corrected; starting ArduPilot .param in the downloads
