SkyG Speed 90B print projects, revision C6B-13 (2026-10-11) - for the Bambu Lab H2S AND H2D

One Bambu Studio project per printed part, oriented as the user manual shows, with every setting embedded (walls,
infill, material per part) and tree supports set to AUTO. There is no G-code inside on purpose: G-code only fits the
printer model it was sliced for. Open the .3mf in Bambu Studio, select your printer (H2S or H2D, 0.4 mm nozzle; the
process settings stay), slice and print. Every part fits both build volumes (340 x 320 x 325 mm). The parts are
checked to print without support, so Bambu adds none or almost none.
Materials (see the BOM): PLA-CF wing halves (2 walls), PETG-CF ailerons, tray, coupler, nut bars, lips, duct inserts,
motor plate, spinner, tail panels and servo horns; PETG camera noses, hatch cover and GPS carrier; ASA tail module and fin. CF filaments need a hardened-steel nozzle.
Every file name ends in _C6B-13: print from one revision only.

Revision C6B-13 (2026-10-11):
- Pi nose window 25 x 0.5 mm (was 25 x 1 mm): no ready-made 25 x 1 mm disc in Turkey; both windows are now cut from one 0.5 mm clear PET (APET) sheet (owner: yes). Face recess 0.5 mm deep
