SkyG Speed 90B print projects, revision C6B-9 (2026-10-11) - for the Bambu Lab H2S AND H2D

One Bambu Studio project per printed part, oriented as the user manual shows, with every setting embedded (walls,
infill, material per part) and tree supports set to AUTO. There is no G-code inside on purpose: G-code only fits the
printer model it was sliced for. Open the .3mf in Bambu Studio, select your printer (H2S or H2D, 0.4 mm nozzle; the
process settings stay), slice and print. Every part fits both build volumes (340 x 320 x 325 mm). The parts are
checked to print without support, so Bambu adds none or almost none.
Materials (see the BOM): PLA-CF wing halves (2 walls), PETG-CF ailerons, tray, coupler, nut bars, lips, duct inserts,
motor plate, spinner, tail panels and servo horns; PETG camera noses, hatch cover and GPS carrier; ASA tail module and fin. CF filaments need a hardened-steel nozzle.
Every file name ends in _C6B-9: print from one revision only.

Revision C6B-9 (2026-10-11):
- DJI duct insert printed in ASA: it had no filament entry and fell back to the PLA Aero default (foamed, softens at 53 °C, against the owner's no-foam rule for the nose) while it holds a module running at about 75 °C
- New design-review gate print_materials: every printed part names its filament, no foamed filament on the noses or the tail, enough heat resistance next to the O4 module, the motor and in the tube
- Viewer: Isolate / Hide / Zoom to part at the top of the selected-part panel
