SkyG Speed 90B print projects, revision C6B-22 (2026-10-16) - for the Bambu Lab H2S AND H2D

One Bambu Studio project per printed part, oriented as the user manual shows, with every setting embedded (walls,
infill, material per part) and tree supports set to AUTO. There is no G-code inside on purpose: G-code only fits the
printer model it was sliced for. Open the .3mf in Bambu Studio, select your printer (H2S or H2D, 0.4 mm nozzle; the
process settings stay), slice and print. Every part fits both build volumes (340 x 320 x 325 mm). The parts are
checked to print without support, so Bambu adds none or almost none.
Materials (see the BOM): PLA-CF wing halves (2 walls), PETG-CF ailerons, tray, coupler, nut bars, lips, duct inserts,
motor plate, spinner, tail panels and servo horns; PETG camera noses, hatch cover and GPS carrier; ASA tail module and fin. CF filaments need a hardened-steel nozzle.
Every file name ends in _C6B-22: print from one revision only.

Revision C6B-22 (2026-10-16):
- Fin shoe faired (owner go 2026-10-16): smooth tangent front ramp from x 372 (was a flat 40 deg ramp from x 383.5) with a curved plan-form nose, and the shoe now runs aft to the fin's trailing edge with a smooth fade (was a 45 deg end at x 440 with the last 20 mm of the fin root uncovered). Screws, inserts, fin, tube openings and the cutting template unchanged; F3 and FN reprint
