SkyG Speed 120 print files (revision C7-2)

One Bambu Studio project per printed part, already oriented as the user manual shows
and sliced for a Bambu Lab H2S, 0.4 mm nozzle, 0.2 mm layers, SUPPORTS OFF, materials as in the BOM
(ASA Aero / PLA Aero for the airframe, PETG-CF for the motor plate and spinner).
Other printers: open the .3mf in your slicer, keep the orientation and supports off, re-slice.
Only one camera nose is needed; the other noses (and their dome ring / VTX shelf) are options.
