SkyG Speed 90B print projects, revision C6B-11 (2026-10-11) - for the Bambu Lab H2S AND H2D

One Bambu Studio project per printed part, oriented as the user manual shows, with every setting embedded (walls,
infill, material per part) and tree supports set to AUTO. There is no G-code inside on purpose: G-code only fits the
printer model it was sliced for. Open the .3mf in Bambu Studio, select your printer (H2S or H2D, 0.4 mm nozzle; the
process settings stay), slice and print. Every part fits both build volumes (340 x 320 x 325 mm). The parts are
checked to print without support, so Bambu adds none or almost none.
Materials (see the BOM): PLA-CF wing halves (2 walls), PETG-CF ailerons, tray, coupler, nut bars, lips, duct inserts,
motor plate, spinner, tail panels and servo horns; PETG camera noses, hatch cover and GPS carrier; ASA tail module and fin. CF filaments need a hardened-steel nozzle.
Every file name ends in _C6B-11: print from one revision only.

Revision C6B-11 (2026-10-11):
- T-Motor F50 2150 KV and Gemfan Vortex 5 × 7.5E on the same 4S 650 pack (owner: "go with your recommendation"): the APC 5 × 7.5E's 30,000 rpm rating forced a 70 % throttle cap on the F405 (63–64 m/s); the F50 cannot spin the Gemfan past its 38,000 rpm ceiling on 4S (36,100 rpm unloaded), so no cap and no governor: about 77–78 m/s
- Motor, spinner and prop placed for the F50's shorter bell (prop 3.3 mm further forward, spinner base Ø27); same motor plate and mount
- Top-speed figures corrected everywhere: C6B-10's viewer and speed results showed 86–87 m/s, which assumed an rpm governor the F405 cannot run
- Parts list: flight battery ≥ 75C (36 A needed; it said ≥ 100C while suggesting a 75C pack), GPS under the PETG (not PLA) hatch cover
